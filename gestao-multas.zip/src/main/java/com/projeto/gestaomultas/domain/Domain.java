package com.projeto.gestaomultas.domain;

public class Domain {

}
