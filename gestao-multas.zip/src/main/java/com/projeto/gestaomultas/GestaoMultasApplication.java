package com.projeto.gestaomultas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestaoMultasApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestaoMultasApplication.class, args);
	}

}
